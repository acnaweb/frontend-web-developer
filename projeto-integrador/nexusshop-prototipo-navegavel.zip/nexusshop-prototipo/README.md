# NexusShop — Protótipo Navegável

Protótipo em **HTML, CSS e JavaScript puro** criado como exemplo visual e funcional do Projeto Integrador do roadmap Frontend Web Developer.

## Funcionalidades

- Home;
- catálogo responsivo;
- busca;
- filtro por categoria;
- filtro por disponibilidade;
- detalhe do produto;
- carrinho;
- alteração de quantidades;
- remoção de itens;
- checkout;
- validação de formulário;
- confirmação do pedido;
- acompanhamento de pedidos;
- área administrativa;
- criação, edição e exclusão de produtos;
- persistência com `localStorage`.

## Estrutura

```text
nexusshop-prototipo/

├── index.html
├── styles.css
├── app.js
└── README.md
```

## Como executar

### Forma mais simples

Abra `index.html` diretamente em um navegador moderno.

### Servidor HTTP local

Caso prefira executar por HTTP:

```bash
cd nexusshop-prototipo
python3 -m http.server 8080
```

Depois abra:

```text
http://localhost:8080
```

## Roteiro sugerido para demonstração

1. Abra a **Home**.
2. Entre no **Catálogo**.
3. Utilize busca e filtros.
4. Abra o detalhe de um produto.
5. Adicione produtos ao carrinho.
6. Altere quantidades.
7. Prossiga para o checkout.
8. Preencha os dados e confirme o pedido.
9. Abra **Pedidos** para visualizar o acompanhamento.
10. Abra **Admin**.
11. Crie, edite ou exclua um produto.
12. Volte ao catálogo e observe a mudança.

## Arquitetura do protótipo

```mermaid
flowchart LR
    U[Usuário] --> HTML[index.html]
    HTML --> JS[app.js]
    JS --> UI[Interface]
    JS --> LS[(localStorage)]
    UI --> R[Hash Router]
    R --> HOME[Home]
    R --> CAT[Catálogo]
    R --> CART[Carrinho]
    R --> CHECK[Checkout]
    R --> ORD[Pedidos]
    R --> ADM[Admin]
```

## Observação

Este projeto é propositalmente simples e não possui backend real.

Ele serve como **protótipo navegável** antes da evolução para:

```text
React
+
API REST
+
Design System
+
Testes
+
CI/CD
+
Deploy
```

Os dados são fictícios e permanecem no navegador por meio de `localStorage`.

Para voltar ao catálogo original, limpe o armazenamento local do site no navegador.
